#pragma once

class BackGround {
public:
	BackGround();
	~BackGround();

	void	Draw();

private:
	int		_cg;		// �摜
};