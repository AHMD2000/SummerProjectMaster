#pragma once

#include	"ModeBase.h"
#include	<vector>
#include	"ObjectBase.h"
#include	"Game.h"
#include	"Effect.h"
#include	"Player.h"

class ModeUI : public ModeBase
{
	typedef ModeBase base;
public:
	virtual bool Initialize(Game& g);
	virtual bool Terminate(Game& g);
	virtual bool Process(Game& g);
	virtual bool Draw(Game& g);


	std::vector<std::pair<int, ObjectBase::OBJECTTYPE>> _plyRankingUI;

protected:

	int _UIcnt = 0;

	int _gaugeX, _gaugeY;

	double _maxCoin;
	double _plyCoinRate[4];

	int _grUIgaugeHandle;

	int _UILimitTime = 0;

	int _finalBGMCoin = 40;

	bool _fadeOn = true;

	bool _finalBGM;

	bool _GameMusic = false;

	bool _GameMusicPerformance = true;

	bool _BGMPerformance = false;

	int _fadeCnt;

	bool _SetModeResult = true;

	std::vector<int> _grAllHandles;

	//�o�i�i
	std::vector<int> _grAllBananaHandles;

	// �G�t�F�N�g�̃��j�[�N�|�C���^�̓��I�z��
	std::vector<std::unique_ptr<Effect>> _effects;

	// �v���C���[�̓��I�z��
	std::vector<Player*> _plys;

	bool _inPlayer = true;


};